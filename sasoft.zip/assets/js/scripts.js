const backToTop = document.querySelector(".back-to-top");
window.addEventListener('scroll', function(){
  if (
    document.body.scrollTop > 50 ||
    document.documentElement.scrollTop > 50
  ) {
    backToTop.style.display = "flex";
  } else {
    backToTop.style.display = "none";
  }
  
})
